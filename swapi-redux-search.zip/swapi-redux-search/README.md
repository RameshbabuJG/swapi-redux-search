# React Swapi

### How do I get set up? ###

* Clone the repo
* npm i
* npm start

### Open Browser ###

 http://localhost:3000

 ### Login

Allow the user to login as a character from STAR WARS using the character name as the username and birth year as the password.

Example:


• Username: Luke Skywalker

• Password : 19BBY