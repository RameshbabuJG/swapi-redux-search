import { EventEmitter } from 'events';

class MyEmitter extends EventEmitter {}
const myEmitter = new MyEmitter();

export default myEmitter;
