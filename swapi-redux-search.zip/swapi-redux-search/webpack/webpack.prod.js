const webpack = require('webpack');

/* Base Config */
const config = require('./webpack.base.js');
process.env.BABEL_ENV = 'production';
process.env.NODE_ENV = 'production';

config.plugins = config.plugins.concat([
  new webpack.optimize.DedupePlugin(),
  new webpack.optimize.UglifyJsPlugin({ mangle: false, sourcemap: false }),
  new webpack.DefinePlugin({
    'process.env.NODE_ENV': JSON.stringify('production'),
  }),
]);

module.exports = config;
