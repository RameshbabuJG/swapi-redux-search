const webpack = require('webpack');
const path = require('path');
const config = require('./webpack.base.js');
config.devtool = 'inline-sourcemap';
process.env.BABEL_ENV = 'development';
process.env.NODE_ENV = 'development';
config.devServer = {
  inline: true,
  progress: true,
  port: 3000,
  hot: true,
//  color:true,
  watchContentBase: true,
  watchOptions: {
    ignored: new RegExp(
      `^(?!${path
        .normalize('src' + '/')
        .replace(/[\\]+/g, '\\\\')}).+[\\\\/]node_modules[\\\\/]`,
      'g'
    ),
  },
 // noInfo: true,
  overlay: false,
  //contentBase: path.join(__dirname, '/'),
  historyApiFallback: {
    // Paths with dots should still use the history fallback.
    // See https://github.com/facebookincubator/create-react-app/issues/387.
    disableDotRule: true,
  },

};
config.plugins = config.plugins.concat([
  new webpack.HotModuleReplacementPlugin(),
]);

module.exports = config;
